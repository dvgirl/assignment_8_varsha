# 📋 Assignment 7: API Design & Planning Document for To-Do List App

---

## 🎯 1. Objective

The objective of this document is to plan and define a complete **RESTful API specification** for the To-Do List / Task Manager application. This document outlines all required endpoints, HTTP methods, request payloads, response structures, CRUD mapping, and potential challenges before building the backend with Node.js & Express.

---

## 🏗️ 2. Resource Overview & Data Model

Each Task object in our backend database / state will follow this schema:

```json
{
  "id": "String or Number (Unique Identifier)",
  "text": "String (Task title / description - Required)",
  "completed": "Boolean (Task status: true / false - Default: false)",
  "createdAt": "String / Date (Timestamp of creation)"
}
```

---

## 📡 3. RESTful API Endpoints Specification

### 🟢 1. Create / Add a Task
* **Functionality**: Adds a new task to the list.
* **Endpoint URL**: `POST /api/tasks`
* **HTTP Method**: `POST`
* **Headers**: `Content-Type: application/json`

#### Request Body:
```json
{
  "text": "Complete React & Node.js Assignment"
}
```

#### Unique Identifier Logic:
- **Approach**: The backend will generate a unique identifier using **UUID (`uuidv4()`)** or **MongoDB `_id`** or **Timestamp (`Date.now()`)**.
- **Reasoning**: Ensures every task has a globally unique ID so operations like edit and delete never conflict.

#### Expected Responses:
- **201 Created (Success)**:
```json
{
  "success": true,
  "message": "Task created successfully",
  "data": {
    "id": "1717584900000",
    "text": "Complete React & Node.js Assignment",
    "completed": false,
    "createdAt": "2026-10-05T12:00:00.000Z"
  }
}
```
- **400 Bad Request (Validation Error)**:
```json
{
  "success": false,
  "message": "Task title (text) is required and cannot be empty."
}
```

---

### 🔵 2. Get All Tasks (Read All)
* **Functionality**: Fetches all tasks from the database. Supports optional filtering by completion status.
* **Endpoint URL**: `GET /api/tasks`
* **Optional Query Parameters**: `?status=all` | `?status=active` | `?status=completed`
* **HTTP Method**: `GET`

#### Expected Responses:
- **200 OK (Success)**:
```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "id": "1",
      "text": "Learn React Context API & useReducer",
      "completed": true,
      "createdAt": "09:00 AM"
    },
    {
      "id": "2",
      "text": "Build responsive Task Manager UI",
      "completed": false,
      "createdAt": "10:30 AM"
    }
  ]
}
```

---

### 🔵 3. Get Single Task by ID (Read One)
* **Functionality**: Retrieves details of a specific task using its unique ID.
* **Endpoint URL**: `GET /api/tasks/:id`
* **HTTP Method**: `GET`

#### Expected Responses:
- **200 OK (Success)**:
```json
{
  "success": true,
  "data": {
    "id": "1",
    "text": "Learn React Context API & useReducer",
    "completed": true,
    "createdAt": "09:00 AM"
  }
}
```
- **404 Not Found (Error)**:
```json
{
  "success": false,
  "message": "Task with ID 999 not found"
}
```

---

### 🟡 4. Update Task Details (Edit Task)
* **Functionality**: Updates the title / description of an existing task.
* **Endpoint URL**: `PUT /api/tasks/:id` (or `PATCH /api/tasks/:id`)
* **HTTP Method**: `PUT`
* **Headers**: `Content-Type: application/json`

#### Request Body:
```json
{
  "text": "Updated Task Description"
}
```

#### Expected Responses:
- **200 OK (Success)**:
```json
{
  "success": true,
  "message": "Task updated successfully",
  "data": {
    "id": "2",
    "text": "Updated Task Description",
    "completed": false,
    "createdAt": "10:30 AM"
  }
}
```
- **404 Not Found (Error)**:
```json
{
  "success": false,
  "message": "Task not found"
}
```

---

### 🟣 5. Toggle Task Completion Status
* **Functionality**: Toggles task completion between `true` and `false`.
* **Endpoint URL**: `PATCH /api/tasks/:id/toggle`
* **HTTP Method**: `PATCH`

#### Request Body: *(Optional / Auto-toggled by backend or passed as boolean)*
```json
{
  "completed": true
}
```

#### Expected Responses:
- **200 OK (Success)**:
```json
{
  "success": true,
  "message": "Task status updated",
  "data": {
    "id": "2",
    "text": "Build responsive Task Manager UI",
    "completed": true,
    "createdAt": "10:30 AM"
  }
}
```

---

### 🔴 6. Delete a Single Task
* **Functionality**: Removes a specific task permanently by ID.
* **Endpoint URL**: `DELETE /api/tasks/:id`
* **HTTP Method**: `DELETE`

#### Expected Responses:
- **200 OK (Success)**:
```json
{
  "success": true,
  "message": "Task deleted successfully",
  "deletedId": "2"
}
```
- **404 Not Found (Error)**:
```json
{
  "success": false,
  "message": "Task not found"
}
```

---

### 🛑 7. Clear All Tasks (Bulk Delete)
* **Functionality**: Clears all tasks from the database.
* **Endpoint URL**: `DELETE /api/tasks`
* **HTTP Method**: `DELETE`

#### Expected Responses:
- **200 OK (Success)**:
```json
{
  "success": true,
  "message": "All tasks cleared successfully"
}
```

---

## 📊 4. CRUD Operations Summary Table

| Operation | Action | HTTP Method | Endpoint | Description |
| :--- | :--- | :--- | :--- | :--- |
| **C** (Create) | Add Task | `POST` | `/api/tasks` | Inserts a new task with unique ID |
| **R** (Read) | Get All Tasks | `GET` | `/api/tasks` | Fetches full list of tasks |
| **R** (Read) | Get Task by ID | `GET` | `/api/tasks/:id` | Fetches a single task |
| **U** (Update) | Edit Task Text | `PUT` | `/api/tasks/:id` | Modifies task description |
| **U** (Update) | Toggle Status | `PATCH` | `/api/tasks/:id/toggle` | Toggles completed boolean |
| **D** (Delete) | Delete One Task | `DELETE` | `/api/tasks/:id` | Removes task by ID |
| **D** (Delete) | Clear All Tasks | `DELETE` | `/api/tasks` | Resets/empties task list |

---

## 💡 5. Reasoning Behind API Design & REST Principles

1. **REST Resource-Oriented URI Naming**:
   - Uses plural nouns (`/api/tasks`) rather than verbs (avoids `/api/addTask` or `/api/deleteTask`), adhering strictly to REST conventions.
2. **Proper HTTP Method Semantics**:
   - `GET` for safe, read-only retrievals.
   - `POST` for resource creation.
   - `PUT`/`PATCH` for full/partial updates.
   - `DELETE` for removal.
3. **Standard HTTP Status Codes**:
   - `200 OK`: Successful operation with payload.
   - `201 Created`: Resource successfully created.
   - `400 Bad Request`: Client error (e.g. empty task text).
   - `404 Not Found`: Target task ID does not exist.
   - `500 Internal Server Error`: Server failure.
4. **Predictable JSON Structure**:
   - Every API response consistently returns `{ success, message, data }` for easy frontend parsing.

---

## ⚠️ 6. Potential Implementation Challenges & Solutions

1. **CORS (Cross-Origin Resource Sharing)**:
   - *Challenge*: React frontend running on port `5173` / `3000` will be blocked when requesting Node.js backend on port `5000`.
   - *Solution*: Enable `cors` middleware in Express (`app.use(cors())`).

2. **Data Validation & Sanitization**:
   - *Challenge*: Empty strings, whitespace-only inputs, or malicious scripts.
   - *Solution*: Validate request body using helper functions or Joi/express-validator to reject empty tasks before saving.

3. **State Synchronization between React & Node.js**:
   - *Challenge*: Keeping React UI in sync with backend without full page reloads.
   - *Solution*: Dispatch reducer actions (`ADD_TASK`, `TOGGLE_TASK`, `DELETE_TASK`) immediately after receiving successful `200`/`201` API responses (Optimistic / Pessimistic UI updates).

4. **Persistent ID Consistency**:
   - *Challenge*: Frontend using timestamp numbers vs MongoDB string ObjectIds.
   - *Solution*: Ensure ID types are standardized as strings across frontend and backend.

---

## 📝 7. Brief Explanation of How the APIs Work

1. **Frontend Request**: When a user types a task in React and clicks "Add Task", React issues an asynchronous `fetch('http://localhost:5000/api/tasks', { method: 'POST', body: JSON.stringify({ text }) })`.
2. **Node.js Express Server Handling**: The Express route `/api/tasks` receives the request, parses the JSON body with `express.json()`, verifies that `text` is not empty, assigns a unique ID and `createdAt` timestamp, and saves it into the database/array.
3. **Backend Response**: The server sends back a `201 Created` status with the newly created task object.
4. **React State Update**: React's `TaskContext` receives the new task from the response and dispatches `{ type: 'ADD_TASK', payload: newTask }` to update the global UI instantaneously.
